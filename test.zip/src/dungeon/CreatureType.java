package dungeon;

/**
 * This is an enumeration for the type of creature in the cave.
 */
public enum CreatureType {

  OTUYGH, MOVING_MONSTER;
}
