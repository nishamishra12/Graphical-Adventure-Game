package dungeon;

/**
 * This is an enumeration for quality of sand in the dunegon when the pit is around.
 */
public enum SoilQuality {
  DENSE, POROUS, NONE
}
